                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><?= $title; ?></h1>
                        <div class="d-sm-flex align-items-center">
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm mr-2"><i
                                class="fas fa-print fa-sm"></i> Cetak</a>
                        <a href="<?= base_url('akuntansi/input_jurnal'); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-plus fa-sm"></i> Tambah Data Transaksi</a>
                        </div>
                        
                    </div>


                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Transaksi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>Nama Akun</th>                                            
                                            <th>No. Akun</th>
                                            <th>Debit</th>
                                            <th>Kredit</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($transaksi as $t) : 
                                        if($t['jenis_saldo']=='Debit'):?>
                                        <tr>
                                          <td><?= $t['tgl']; ?></td>
                                          <td><?= $t['nama_akun']; ?></td>
                                          <td><?= $t['no_akun']; ?></td>
                                          <td><?= 'Rp. '.number_format($t['saldo'],0,',','.'); ?></td>
                                          <td></td>
                                          <td>
                                              <a href="" class="badge badge-pill badge-warning">Detail</a>
                                              <a href="" class="badge badge-pill badge-success">Edit</a>
                                              <a href="" class="badge badge-pill badge-danger">Hapus</a>
                                          </td>
                                        </tr>

                                        <?php 
                                        endif;
                                        if($t['jenis_saldo']=='Kredit'):
                                        ?>

                                        <tr>
                                          <td><?= $t['tgl']; ?></td>
                                          <td><?= $t['nama_akun']; ?></td>
                                          <td><?= $t['no_akun']; ?></td>
                                          <td></td>
                                          <td><?= 'Rp. '.number_format($t['saldo'],0,',','.'); ?></td>
                                          <td>
                                              <a href="" class="badge badge-pill badge-warning">Detail</a>
                                              <a href="" class="badge badge-pill badge-success">Edit</a>
                                              <a href="" class="badge badge-pill badge-danger">Hapus</a>
                                          </td>
                                        </tr>
                                        <?php endif;?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

