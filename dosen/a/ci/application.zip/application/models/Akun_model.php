<?php 

class Akun_model extends CI_model {
    public function getAllAkun()
    {
        return $this->db->get('akun')->result_array();
    }

    public function tambahAkun()
    {
        $data = [
            "no_akun" => $this->input->post('no_akun', true),
            "nama_akun" => $this->input->post('nama_akun', true),
            "kel_akun" => $this->input->post('kel_akun', true)
        ];

        $this->db->insert('akun', $data);
    }

    public function hapusAkun($id)
    {
        // $this->db->where('id', $id);
        $this->db->delete('akun', ['id' => $id]);
    }

    public function getAkunById($id)
    {
        return $this->db->get_where('akun', ['id' => $id])->row_array();
    }

    public function editAkun()
    {
        $data = [
            "no_akun" => $this->input->post('no_akun', true),
            "nama_akun" => $this->input->post('nama_akun', true),
            "kel_akun" => $this->input->post('kel_akun', true)
        ];
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('akun', $data);
    }
 


}