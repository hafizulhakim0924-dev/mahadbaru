<?php
header("Location: profile.php");
exit;
